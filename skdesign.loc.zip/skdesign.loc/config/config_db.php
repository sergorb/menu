<?php
return [
    'dsn' => 'mysql:host=localhost;dbname=skdesign;charset=utf8',
    'user' => 'root',
    'password' => '',
];