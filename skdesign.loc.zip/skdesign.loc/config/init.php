<?php
define("DEBUG", 1);
define("ROOT", dirname(__DIR__));
define("WWW", ROOT . '/public');
define("APP", ROOT . '/app');
define("CORE", ROOT . '/vendor/core');
define("LIBS", ROOT . '/vendor/libs');
define("CACHE", ROOT . '/tmp/cache');
define("CONF", ROOT . '/config');
define("VENDOR", ROOT . '/vendor');
define("LAYOUT", 'main_layout');
define("SITE_URL", '/');
define("JS", SITE_URL . 'public/js');
define("CSS", SITE_URL . 'public/css/');