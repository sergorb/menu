<?php
use vendor\core\Router;
Router::add('/^$/i', ['controller' => 'Main', 'action' => 'index']);
Router::add('/^(?P<controller>[a-z-]+)\/?(?P<action>[a-z-]+)?$/i');