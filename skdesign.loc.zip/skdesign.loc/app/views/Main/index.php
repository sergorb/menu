<div class="contant">
	<?php foreach($products as $product): ?>
		<p><?= $product['name'] ?></p>
	<?php endforeach ?>
</div>