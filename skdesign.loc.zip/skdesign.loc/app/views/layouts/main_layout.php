<!DOCTYPE HTML>
<html lang="ru">
<head>
    <title></title>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta charset = "utf-8">
    <meta http-equiv="Content-Type" content="text/html"/>
    <meta name="viewport" content="initial-scale=1.0, width=device-width">
	<link rel="stylesheet" type="text/css" href="<?= CSS ?>content-main.css"/>
</head>
<body>
	<div class="container">
		<p><a href="<?= SITE_URL ?>">Все товары</a></p>
		<?php new \app\widgets\menu\Menu([
			//'tpl' => WWW . '/menu/menu.php',
			//'attrs' => ['style' => 'color:red;'],
			'table' => '`groups`',
		]) ?>
		<?= $content; ?>
	</div>
<script src="<?= JS; ?>/jquery-1.11.0.min.js"></script>
<script src="<?= JS; ?>/script.js"></script>
</body>
</html>