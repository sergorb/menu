<?php
namespace app\widgets\menu;

use app\controllers\AppController;
use vendor\core\TSingletone;

class Menu {
	protected $data;
    protected $tree;
	protected $menuHtml;
    protected $tpl;
    protected $container = 'ul';
	protected $class = 'menu';
    protected $table;
    protected $attrs = [];
	protected static $pdo;
	
	use TSingletone;
	
	public function __construct($options = []){
        $this->tpl = __DIR__ . '/menu_tpl/menu.php';
        $this->getOptions($options);
        //debug($this->table);
		
		self::$pdo = AppController::getPDO();
        $this->run();
    }
	
	protected function getOptions($options){
        foreach($options as $k => $v){
            if(property_exists($this, $k)){
                $this->$k = $v;
            }
        }
    }
	
	protected function run(){
        $query = self::$pdo->query("SELECT * FROM {$this->table}");
        $arr = $query->fetchALL();
		
		if($arr === false){
            throw new \Exception("Ошибка в получении категорий из БД", 404);
        }
		//debug($arr);

		// Перезаписываю ключи массива, чтобы не с нуля
		foreach($arr as $val){
            $this->data[$val['id']] = $val;
		}
		//debug($this->data);

		$this->tree = $this->getTree();
		//debug($this->tree);
		
		$this->menuHtml = $this->getMenuHtml($this->tree);
		
        $this->output();
    }
	
	protected function output(){	
        $attrs = '';
        if(!empty($this->attrs)){
            foreach($this->attrs as $k => $v){
                $attrs .= " $k='$v' ";
            }
        }
		
        echo "<{$this->container} class='{$this->class}' $attrs>";
            echo $this->menuHtml;
        echo "</{$this->container}>";
    }
	
	protected function getTree(){
        $tree = [];
        $data = $this->data;
        foreach ($data as $id=>&$node) {
            if (!$node['id_parent']){
                $tree[$id] = &$node;
            }else{
                $data[$node['id_parent']]['childs'][$id] = &$node;
            }
        }
        return $tree;
    }
	
	protected function getMenuHtml($tree){
		$str = '';
        foreach($tree as $id => $category){
            $str .= $this->catToTemplate($category, $id);
        }
        return $str;
    }

    protected function catToTemplate($category, $id){
		ob_start();
        require $this->tpl;
        return ob_get_clean();
    }
}
