<?php

namespace app\controllers;

use \vendor\core\base\Controller;
use \vendor\core\base\Model;

class AppController extends Controller{

    protected static $pdo;

    public function __construct($route) {
        parent::__construct($route);
        $model = Model::instance();
        self::$pdo = $model -> getPDO();
    }

    public static function getPDO(){
        return self::$pdo;
    }
}