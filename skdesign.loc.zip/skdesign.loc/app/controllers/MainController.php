<?php
namespace app\controllers;

use app\models\Main;

class MainController extends AppController{
	
	public function indexAction() {
		//http://skdesign.loc
		
		$model = new Main();
		
		if(!empty($_GET)){
			$id = !empty($_GET['group']) ? (int)($_GET['group']) : null;
			//debug($id);
			
			$categories = $model->groups();
			//debug($groups);
			
			$ids = $model->catsId($categories, $id);
			$ids = !$ids ? $id : rtrim($ids, ",");
			//debug($ids);
			
			$sql = "SELECT id, name, id_group FROM `products` WHERE id_group IN ($ids)";
			$products = $model->products($sql);
		} else {
			$sql = "SELECT id, name, id_group FROM `products`";
			$products = $model->products($sql);
		}
		
		$this->set(compact('products'));
    }
}