<?php
namespace app\models;

use app\controllers\AppController;

class AppModel {
    protected static $pdo;
    public $attributes = [];
    public $rules = [];

    public function __construct() { 
        self::$pdo = AppController::getPDO();
    }
    public static function clearStr($data){
        return self::$pdo->quote(trim(strip_tags($data)));
    }
}