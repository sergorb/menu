<?php
namespace app\models;

class Main extends AppModel{
	
	public function groups(){ 
		$sql = "SELECT * FROM `groups`";
        $query = self::$pdo->query($sql);
        $arr = $query->fetchALL();
		foreach($arr as $val){
            $data[$val['id']] = $val;
		}
		return $data;
    }
	
	public function products($sql){ 
        $query = self::$pdo->query($sql);
        $arr = $query->fetchALL();
        return $arr;
    }
	
	function catsId($array, $id){
		if(!$id) return false;
		$data = '';
		foreach($array as $item){
			if($item['id_parent'] == $id){
				$data .= $item['id'] . ",";
				$data .= $this->catsId($array, $item['id']);
			}
		}
		return $data;
	}
}
