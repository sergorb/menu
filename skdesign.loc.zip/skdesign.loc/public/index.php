<?php
use vendor\core\App;

require_once dirname(__DIR__) . '/config/init.php';
require_once LIBS . '/functions.php';
spl_autoload_register(function($class){
    $file = ROOT . '/' . str_replace('\\', '/', $class) . '.php';
    if(is_file($file)){
        require_once $file;
    }
});
require_once CONF . '/routes.php';
new App();