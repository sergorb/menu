<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ошибка</title>
</head>
<body>

    <h1>Произошла ошибка</h1>
    <p>Код ошибки: <?= $errno; ?></p>
    <p>Текст ошибки: <?= $errstr; ?></p>
    <p>Файл в котором произошла ошибка: <?= $errfile; ?></p>
    <p>Строка в которой произошла ошибка: <?= $errline; ?></p>

</body>
</html>

