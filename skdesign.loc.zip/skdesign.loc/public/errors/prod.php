<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ошибка</title>
</head>
<body>

    <h1>Произошла ошибка</h1>

</body>
</html>

