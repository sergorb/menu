<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>404 Not Found</title>
</head>
<body>
    <h1>404 Страница не найдена</h1>
    <div><a href="<?= SITE_URL; ?>">На главную</a></div>
</body>
</html>